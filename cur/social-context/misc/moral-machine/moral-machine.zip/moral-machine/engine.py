'''
Provides template code to automatically make decisions for the autonomous
car.
'''
from scenario import Scenario

def decide(scenario):
    """ Decides whether your car will save the passengers or pedestrians
    Args:
        scenario: a Scenario object defined in scenario.py. This object contains
            all of the information about the scenario. You can see some
            examples below in the sample code.
    Returns:
        A string indicating whether you are saving "passengers" or
        "pedestrians". Note that your method MUST make a decision for
        ANY potential scenario.
    """

    # Your program must choose to save either pedestrians or passengers.
    # This is an overly simple rule that only saves the passengers if there are
    # more passengers than pedestrians. Please replace this with your own code.
    if scenario.numPassengers > scenario.numPedestrians:
        return "passengers"
    else:
        return "pedestrians"