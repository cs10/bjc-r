import zlib, base64
exec(zlib.decompress(base64.b64decode('eJxdjlEKwjAQRP9ziqU/VT88gKBnEDzBkkw1mGTL7rbo7dWCiv7OmzdM3/fhqDLnBCNHHQs7KEoCuRBPLpU9Ry7lTpWvoISYLUszGkTJL1hKTapMFiLrNvTPydNN7/O+oIVBpZJFNNYslOso6puQMCxLCas3W+8C5YEW8xNuRzZDO0NtffhHeH52zdzs5ZLCJ23UfZUuEIrhB36lLjwAyC9ZyA==')))
# Created by pyminifier (https://github.com/liftoff/pyminifier)