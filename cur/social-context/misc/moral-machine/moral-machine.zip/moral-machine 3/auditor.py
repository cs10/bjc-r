from engine import decide
from scenario import Scenario


def audit():
    ''' Determines if the ethical engine exhibits any biases towards
    different people groups.
    The audit method should print out two lists of attributes that explain
    how the underlying ethical engine is making decisions.
        - The first list should contain attributes in which the autonomous
        car is biased towards SAVING
        - The second list should contain attributes in which the autonomous
        car is biased towards KILLING
    In both lists, the attributes should be roughly ranked based on the
    severity of the bias. This might not be perfect, but should at least
    detect significant trends.
    To accomplish this, write a program that runs many thousands of scenarios
    (at least 10000) and keep track of the results.
    '''

    chosen = {'cat': 0, 'dog': 0, 'baby': 0, 'child': 0, 
    'adult': 0, 'elderly': 0, 'doctor': 0, 'CEO': 0, 'criminal': 0, 
    'unemployed': 0, 'male': 0, 'female': 0, 'pregnant': 0}
    present = {'cat': 0, 'dog': 0, 'baby': 0, 'child': 0, 
    'adult': 0, 'elderly': 0, 'doctor': 0, 'CEO': 0, 'criminal': 0, 
    'unemployed': 0, 'male': 0, 'female': 0, 'pregnant': 0}

    for _ in range(10000):
        scenario = Scenario()
        decision = decide(scenario)
        survived = scenario.passengers if decision == 'passengers' else scenario.pedestrians
        update_dict(scenario.passengers, present)
        update_dict(scenario.pedestrians, present)
        update_dict(survived, chosen)

    prop_survived = {}
    for key in chosen:
        if present[key]:
            prop_survived[key] = chosen[key] / present[key]

    sorted_individuals = sorted(prop_survived, key=prop_survived.get, reverse=True)

    for i in sorted_individuals:
        print('{}: {}%'.format(i, int(prop_survived[i] * 100)))
        

def update_dict(individuals, dict):
    for i in individuals:

        if i.charType == 'human':
            dict[i.age] += 1
            dict[i.gender] += 1
            if i.pregnant:
                dict['pregnant'] += 1
            if i.profession and i.profession != 'unknown':
                dict[i.profession] += 1

        elif i.charType in i.ANIMAL_TYPES:
            dict[i.charType] += 1


if __name__ == '__main__':
    audit()