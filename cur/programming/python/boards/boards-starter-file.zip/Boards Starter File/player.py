from board import *

POS = [0, 0]

# Player Movement Functions

def finish_move():
    pass

def up():
    if POS[0] - 1 >= 0:
        # TODO: Change row
        finish_move()

def down():
    if POS[0] + 1 < SIZE:
        # TODO: Change row
        finish_move()

def left():
    if POS[1] - 1 >= 0:
        # TODO: Change column
        finish_move()

def right():
    if POS[1] + 1 < SIZE:
        # TODO: Change column
        finish_move()

def click(x, y):
    if inside_board(x, y):
        row, col = find_row(y), find_col(x)
        # TODO: Create an item at the given row & column coordinate