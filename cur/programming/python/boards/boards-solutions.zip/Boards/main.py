from board import *
from player import *

# Main Game Loop
window = turtle.Screen()
window.title('Boards')
window.bgcolor("white")

turtle.shape('turtle')
turtle.color('black')
turtle.speed(20)

draw_square_board()
draw_instructions() 

turtle.goto(find_x_y(0, 0))
turtle.showturtle()

# Game loop

window.listen()

window.onkeypress(up, "Up")
window.onkeypress(down, "Down")
window.onkeypress(left, "Left")
window.onkeypress(right, "Right")
window.onclick(click)

turtle.mainloop()