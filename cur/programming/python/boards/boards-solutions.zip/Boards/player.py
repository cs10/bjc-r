from board import *

POS = [0, 0]

# Player Movement Functions

def finish_move():
    if (get_item(POS[0], POS[1]) != 0):
        POS[0] = 0
        POS[1] = 0
    go_to_row_col(POS[0], POS[1])

def up():
    if POS[0] - 1 >= 0:
        POS[0] -= 1
        finish_move()

def down():
    if POS[0] + 1 < SIZE:
        POS[0] += 1
        finish_move()

def left():
    if POS[1] - 1 >= 0:
        POS[1] -= 1
        finish_move()

def right():
    if POS[1] + 1 < SIZE:
        POS[1] += 1
        finish_move()

def click(x, y):
    if inside_board(x, y):
        row, col = find_row(y), find_col(x)
        create_item('circle', row, col)