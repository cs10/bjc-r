import turtle

def create_board(N):
    board = []
    for i in range(N): 
        row = []
        for j in range(N): 
            row.append(0)
        board.append(row)
    return board

SIZE = 8
BOARD = create_board(SIZE)
DISPLAYWIDTH = 300
START = [-(DISPLAYWIDTH / 2), (DISPLAYWIDTH / 2)]
STEP = DISPLAYWIDTH / SIZE


def inside_board(x, y):
    return x > START[0] and x < START[0] + DISPLAYWIDTH and y < START[1] and y > START[1] - DISPLAYWIDTH

def create_item(obj, row, col):
    set_item(obj, row, col)
    draw_obj(obj, row, col)

# Pre-Defined Functions

def draw_board_line():
    turtle.pendown()
    turtle.forward(DISPLAYWIDTH)
    turtle.penup()
    turtle.backward(DISPLAYWIDTH)

def draw_square_board():
    turtle.penup()
    turtle.goto(START[0], START[1])
    turtle.pendown()
    for _ in range(SIZE + 1):
        draw_board_line()
        turtle.right(90)
        turtle.forward(STEP)
        turtle.left(90)
    turtle.goto(START[0], START[1])
    turtle.right(90)
    for _ in range(SIZE + 1):
        draw_board_line()
        turtle.left(90)
        turtle.forward(STEP)
        turtle.right(90)
    turtle.hideturtle()
    turtle.left(90)
    turtle.penup()

def draw_instructions():
    turtle.penup()
    turtle.goto(-180, 290)
    turtle.write("Click to create bug. Move with arrow keys.", font=("Arial", 20, "normal"))

def go_to_row_col(row, col): # moves turtle to a given row, col coordinate on the board
    x, y = find_x_y(row, col)
    turtle.goto(x, y)

def find_x_y(row, col): # row, col --> x, y
    x = (START[0] + STEP * col) + (STEP / 2)
    y = (START[1] - STEP * row) - (STEP / 2)
    return (x, y)

def find_row(y_coord): # y-coord --> row number
    return int(abs(y_coord - START[1]) // STEP)

def find_col(x_coord): # x-coord --> column number
    return int(abs(x_coord - START[0]) // STEP)

def set_item(item, row, col): # changes a given value in underlying board representation
    BOARD[row][col] = item

def get_item(row, col): # returns a given value in underlying board representation
    return BOARD[row][col]

def draw_obj(obje, row, col): # makes a turtle and places it on the board to act as an obstacle
    obj = turtle.Turtle()
    obj.hideturtle()
    obj.penup()
    obj.goto(find_x_y(row, col))
    obj.shape(obje)
    obj.color("red")
    obj.shapesize(0.50, 0.50)
    obj.showturtle()
   