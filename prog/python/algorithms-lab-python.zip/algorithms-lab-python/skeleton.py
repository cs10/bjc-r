def findNumberInUnsortedList(x, lst):
	"""
	Return the index of x if x is in the unsorted list and -1 otherwise.

	Don't forget that Python zero-indexes!

	Parameters
	----------
	x : int
		The number that we are trying to find.
	lst: list
		An unsorted list that may or may not contain x.
	"""
	#TODO: Your code here.


def findNUmberInSortedList(x, lst):
	import math #DO NOT delete this line if you plan on using the skeleton code we provided!
	"""
	Return the index of x if x is in the sorted list and -1 otherwise.
	We have given you some skeleton code below to get you started, 
	but feel free to write your own from scratch.

	Don't forget that Python zero-indexes!

	Parameters
	----------
	x : int
		The number that we are trying to find.
	lst: list
		An SORTED list that may or may not contain the number x.
	"""
	#TODO: Your code here.
	minIndex = ...
	maxIndex = ...
	while ...:
		midIndex = math.floor((minIndex + maxIndex) // 2)
		if ...:
			minIndex = ...
		elif ...:
			maxIndex = ...
		else:
			return ...
	return ...


storage = {} #You should access from and save data to this dictionary
def findNUmberInSortedListMemo(x, lst):
	"""
	Return the index of x if x is in the sorted list and -1 otherwise.

	Note that we have defined a dictionary "storage" for you. 
	This is the dictionary you want to check and update.

	Try to use your already implemented findNumberInSortedList function,
	and Don't forget that Python zero-indexes!

	Parameters
	----------
	x : int
		The number that we are trying to find.
	lst: list
		An SORTED list that may or may not contain the number x.
	"""
	#TODO: Your code here
