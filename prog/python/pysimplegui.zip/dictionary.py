import PySimpleGUI as sg
from gtts import gTTS
import requests
import io
import pygame

# Initialize Pygame mixer
pygame.mixer.init()

# Define the layout for the GUI
layout = [
    [sg.Text('Enter a word:'), sg.InputText(key='WORD')],
    [sg.Button('Search'), sg.Button('Exit')],
    [sg.Multiline(size=(80, 20), key='DEFINITION')]
]

# Create the window
window = sg.Window('Dictionary with TTS', layout)

# Event Loop
while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Exit':
        break
    
    if event == 'Search':
        word = values['WORD']
        response = requests.get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}")
        if response.status_code == 200:
            definition_data = response.json()
            definitions = definition_data[0]['meanings'][0]['definitions'][0]['definition']
            window['DEFINITION'].update(definitions)
            
            # Use gTTS to convert the definition to speech
            tts = gTTS(text=definitions, lang='en')
            fp = io.BytesIO()
            tts.write_to_fp(fp)
            fp.seek(0)
            
            # Load the in-memory file into Pygame mixer
            pygame.mixer.music.load(fp)
            pygame.mixer.music.play()
            
            # Wait for the audio to finish playing
            while pygame.mixer.music.get_busy():  
                pygame.time.Clock().tick(10)
        else:
            sg.popup(f"Could not find the definition for {word}. Please try another word.")

window.close()
