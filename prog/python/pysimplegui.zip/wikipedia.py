import wikipediaapi
import PySimpleGUI as sg

# Initialize Wikipedia API wrapper
wiki_wiki = wikipediaapi.Wikipedia('english')

def get_wikipedia_summary(term):
    page = wiki_wiki.page(term)
    if not page.exists():
        return "Page not found."
    else:
        return page.summary

# GUI Theme
sg.theme('DarkTeal9')

# Define the GUI layout with more style
layout = [
    [sg.Text("Wikipedia Quick Summary", font=("Helvetica", 24), justification='center', pad=(0, 20))],
    [sg.Text("Enter a term to search on Wikipedia:", font=("Helvetica", 14))],
    [sg.InputText(key='-TERM-', font=("Helvetica", 12), size=(40, 1))],
    [sg.Button('Search', bind_return_key=True, button_color=('white', 'springgreen4')),
     sg.Button('Exit', button_color=('white', 'firebrick3'))],
    [sg.Multiline(size=(80, 20), key='-OUTPUT-', font=("Helvetica", 12), disabled=True)]
]

# Create the window with a title and a fixed size
window = sg.Window('Wikipedia Search Tool', layout, size=(600, 500), resizable=True)

# Event loop
while True:
    event, values = window.read()
    if event in (sg.WIN_CLOSED, 'Exit'):
        break
    if event == 'Search':
        search_term = values['-TERM-'].strip()
        if search_term:
            summary = get_wikipedia_summary(search_term)
            window['-OUTPUT-'].update(summary)
        else:
            sg.popup("Please enter a search term.", title="Input Required")

window.close()
