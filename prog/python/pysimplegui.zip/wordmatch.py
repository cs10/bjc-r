import PySimpleGUI as sg
import random

import random

class WordMatch:
    """
    A class to represent a game of WordMatch.
    """

    def __init__(self, word_list):
        """
        Initializes the game with a list of words.
        
        >>> game = WordMatch(['apple'])
        >>> game.chosen_word in ['apple']
        True
        """
        self.word_list = word_list
        self.reset_game()

    def reset_game(self):
        """
        Resets the game by choosing a new word and resetting variables.
        
        >>> game = WordMatch(['apple'])
        >>> game.reset_game()
        >>> game.attempts
        7
        >>> game.guessed_letters
        set()
        >>> "_" in game.display_word
        True
        """
        self.chosen_word = random.choice(self.word_list)
        self.display_word = ["_" if c.isalpha() else c for c in self.chosen_word]
        self.attempts = 7
        self.guessed_letters = set()

    def guess_letter(self, letter):
        """
        Processes the player's guess.

        If the letter is in the word and has not been guessed before,
        it updates the displayed word. Otherwise, it reduces the number
        of attempts left.

        >>> game = WordMatch(['apple'])
        >>> game.chosen_word = 'apple'  # Setting it for the sake of test
        >>> game.guess_letter('a')
        >>> game.display_word
        ['a', '_', '_', '_', '_']
        >>> game.guess_letter('b')
        >>> game.attempts
        6
        >>> len(game.guessed_letters)
        2
        """
        if letter.lower() in self.chosen_word and letter.lower() not in self.guessed_letters:
            self.update_display_word(letter.lower())
        else:
            self.attempts -= 1

        self.guessed_letters.add(letter.lower())

    def update_display_word(self, letter):
        """
        Updates the displayed word with the guessed letter.

        >>> game = WordMatch(['apple'])
        >>> game.chosen_word = 'apple'  # Setting it for the sake of test
        >>> game.update_display_word('p')
        >>> game.display_word
        ['_', 'p', 'p', '_', '_']
        """
        for idx, char in enumerate(self.chosen_word):
            if char == letter:
                self.display_word[idx] = letter

    def has_won(self):
        """
        Checks if the player has won.

        >>> game = WordMatch(['apple'])
        >>> game.chosen_word = 'apple'  # Setting it for the sake of test
        >>> game.display_word = list('apple')
        >>> game.has_won()
        True
        """
        return "_" not in self.display_word

    def has_lost(self):
        """
        Checks if the player has lost.

        >>> game = WordMatch(['apple'])
        >>> game.attempts = 0
        >>> game.has_lost()
        True
        """
        return self.attempts == 0

    def get_display_word(self):
        """
        Returns a string representation of the display word.

        >>> game = WordMatch(['apple'])
        >>> game.display_word = ['a', '_', '_', 'l', 'e']
        >>> game.get_display_word()
        'a _ _ l e'
        """
        return " ".join(self.display_word)

    def get_attempts_left(self):
        """
        Returns the number of attempts left as a string.

        >>> game = WordMatch(['apple'])
        >>> game.attempts = 5
        >>> game.get_attempts_left()
        '5'
        """
        return str(self.attempts)


def create_window(game):
    layout = [
        [sg.Text('WordMatch Game', font=('Helvetica', 16))],
        [sg.Text('Word:'), sg.Text(' '.join(game.get_display_word()), key='-WORD-')],
        [sg.Text('Attempts left:'), sg.Text(game.get_attempts_left(), key='-ATTEMPTS-')],
        [sg.Button(c, key=c, button_color=('white', 'blue')) for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'],
        [sg.Button('New Game', key='-NEW-'), sg.Button('Exit', key='-EXIT-')]
    ]
    return sg.Window('WordMatch', layout)

def play_game():
    # List of words for the WordMatch game
    word_list = ['apple', 'banana', 'cherry', 'date', 'beauty', 'grape', 'honeydew', 'kiwi', "soda"]

    # Create an instance of the WordMatch
    game = WordMatch(word_list)

    # Create the window
    window = create_window(game)

    # Game loop
    while True:
        event, values = window.read()
        
        if event == sg.WIN_CLOSED or event == '-EXIT-':
            break

        if event == '-NEW-':
            game.reset_game()
            window['-WORD-'].update(game.get_display_word())
            window['-ATTEMPTS-'].update(game.get_attempts_left())
            for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                window[c].update(button_color=('white', 'blue'), disabled=False)
        elif event in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' and not game.has_lost():
            game.guess_letter(event)
            window['-WORD-'].update(game.get_display_word())
            window['-ATTEMPTS-'].update(game.get_attempts_left())
            window[event].update(button_color=('white', 'red'), disabled=True)
            
            if game.has_won():
                sg.popup('Congratulations, you won!', title='Game Over')
                break
            elif game.has_lost():
                sg.popup(f'Sorry, you lost! The word was {game.chosen_word}', title='Game Over')
                break

    window.close()

if __name__ == "__main__":
    play_game()