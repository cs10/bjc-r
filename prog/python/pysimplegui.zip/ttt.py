from colorama import Fore, Back, Style, init

init()

class TicTacToe:
    def __init__(self):
        self.board = [[" " for _ in range(3)] for _ in range(3)]

    def __str__(self):
        board_str = Style.BRIGHT
        for i, row in enumerate(self.board):
            for j, cell in enumerate(row):
                if cell == "X":
                    board_str += Fore.BLUE
                elif cell == "O":
                    board_str += Fore.RED
                else:
                    board_str += Fore.WHITE

                if (i + j) % 2 == 0:  # Check for an even sum of indices for a cell
                    board_str += Back.YELLOW

                board_str += cell + Fore.RESET + Back.RESET + " | "
            board_str = board_str.rstrip(" | ") + Style.RESET_ALL + "\n" + "---+---+---\n"
        board_str = board_str.rstrip("---+---+---\n")
        return board_str
game = TicTacToe()
game.board = [["X", "O", "X"], ["O", "", ""], ["", "", "X"]]
print(game)