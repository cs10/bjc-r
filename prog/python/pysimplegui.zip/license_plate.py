import PySimpleGUI as sg
import cv2

# Function to resize image while maintaining aspect ratio
def resize_image(img, width=None, height=None, inter=cv2.INTER_AREA):
    (h, w) = img.shape[:2]

    if width is None and height is None:
        return img

    if width is None:
        # calculate the ratio of the height and construct the dimensions
        r = height / float(h)
        dim = (int(w * r), height)
    else:
        # calculate the ratio of the width and construct the dimensions
        r = width / float(w)
        dim = (width, int(h * r))

    # resize the image
    resized = cv2.resize(img, dim, interpolation=inter)
    return resized

# Define the window's contents
layout = [
    [sg.Text("Upload an image with a car license plate")],
    [sg.Input(size=(25, 1), key='-FILE-'), sg.FileBrowse(file_types=(("JPEG Files", "*.jpeg"), ("JPG Files", "*.jpg"), ("PNG Files", "*.png")))],
    [sg.Image(key='-IMAGE-')],
    [sg.Button('Detect License Plates'), sg.Button('Exit')],
    [sg.Text('Number of license plates detected: 0', key='-NUM_PLATES-')]
]

# Create the window
window = sg.Window('License Plate Detector', layout)

# Load the license plate classifier
plate_cascade = cv2.CascadeClassifier('haarcascade_russian_plate_number.xml')

# Display and interact with the Window
while True:
    event, values = window.read()
    if event == 'Exit' or event == sg.WIN_CLOSED:
        break
    if event == 'Detect License Plates':
        # Get the file chosen by the user
        file_path = values['-FILE-']
        if file_path != '':
            # Read the image file
            img = cv2.imread(file_path)
            
            # Resize the image to a width of 500 pixels
            img = resize_image(img, width=500)

            # Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # Detect plates
            plates = plate_cascade.detectMultiScale(gray, 1.1, 10)
            
            # Draw rectangles around the plates
            for (x, y, w, h) in plates:
                cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)

            # Update the number of plates detected
            window['-NUM_PLATES-'].update(f'Number of license plates detected: {len(plates)}')

            # Convert to bytes for PySimpleGUI
            imgbytes = cv2.imencode('.png', img)[1].tobytes()
            # Update the image in the window
            window['-IMAGE-'].update(data=imgbytes)

# Finish up by removing from the screen
window.close()
