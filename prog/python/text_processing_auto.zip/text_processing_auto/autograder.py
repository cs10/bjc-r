import doctest
from word_analyzer import *
import sys

"""These functions must be defined in a file called word_analyzer.py
in order for this autograder to run"""
functions = {"pig_latin": pig_latin, "izzle": izzle, "apply_language_game": apply_language_game,
            "count_words": count_words,
            "top_n_words": top_n_words, 
            "print_top_n_words": print_top_n_words, 
            "average_word_length": average_word_length
            }
optional = {"top_n_words_except": top_n_words_except, 
            "word_diversity": word_diversity, "get_kgram": get_kgram,
            "process_character": process_character,
            "build_markov_model": build_markov_model}

def run_tests(function=None):
    runner = doctest.DocTestRunner()
    failures = 0
    tries = 0
    tests = doctest.DocTestFinder().find(function)
    for test in tests:
        runner.run(test)
        runner.summarize(verbose=True)
        failures += runner.failures 
        tries += runner.tries
    return failures, tries


"""If an argument is specified in the comamnd line, this program
will run all tests for the specified function. Otherwise,
the program runs all test cases in the function dictionary.
For example, running (python3 autograder.py) in the terminal
will run all test cases. Running (python3 autograder.py function) runs
only the specific function in the terminal.
Author: Mehul Gandhi
""" 
def main():
    #Tests all functions
    #Input from terminal: python3 autograder.py
    #Or test all optional functions: python3 autograder.py optional
    global functions 
    failures, tries = 0, 0
    if len(sys.argv) == 1 or (len(sys.argv) == 2 and sys.argv[1] == "optional"):
        if (len(sys.argv) == 2 and sys.argv[1] == "optional"):
            functions = optional
        for key, function in functions.items():
            print(f"\n=========== RUNNING TEST CASES FOR {key} ===========\n")
            result =  run_tests(function)
            failures += result[0]
            tries += result[1]
        if failures != 0:
            print(f"\n=========== {tries - failures}/{tries} TEST CASES PASSED! ===========\n")
        else:
            print("\n=========== ALL TEST CASES PASSED ===========\n")
    else:
        #Tests only one function
        #Example input from terminal: python3 autograder.py pig_latin
        argument = sys.argv[1]

        #Allows users to test the optional functions in the lab
        if argument in optional:
            functions = optional
        try:
            function = functions[argument]
            print(f"\n=========== RUNNING TEST CASES FOR {argument} ===========\n")
            result =  run_tests(function)
            failures += result[0]
            tries += result[1]           
            if failures != 0:
                print(f"\n=========== {tries - failures}/{tries} TEST CASES PASSED! ===========\n")
            else:
                print("\n=========== ALL TEST CASES PASSED ===========\n")
        except Exception as e:
            print(f"Function not found: {e}")


if __name__ == "__main__":
    main()
