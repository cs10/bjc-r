def read_file(filename):
    """Returns the text contained in file with given filename."""
    #YOUR CODE HERE
    pass


def pig_latin(word):
    """ Returns the pig latin translation of a word.
    >>> pig_latin("hello")
    'ellohay'
    >>> x = pig_latin("hello") #makes sure that the value is being returned, not printed
    >>> x
    'ellohay'
    >>> pig_latin("It") #Since the first letter is a vowel, do not move any characters
    'Itay'
    >>> lst = "The Beauty and Joy of Computing".split()
    >>> " ".join([pig_latin(x) for x in lst])
    'eThay eautyBay anday oyJay ofay omputingCay'
    """

    #YOUR CODE HERE
    return ...


def izzle(word):
    """ Returns the izzle translation of a word. 
    >>> x = izzle("Merry")
    >>> x
    'Mizzle'
    >>> izzle('my') in ["myizzle", 'izzle']
    True
    >>> izzle("dentist")
    'dentizzle'
    >>> lst = "The quick brown fox jumps over the lazy dog".split()
    >>> result = []
    >>> for word in lst:
    ...     result.append(izzle(word))
    >>> result = " ".join(result)
    >>> a1 = 'Thizzle quizzle brizzle fizzle jizzle ovizzle thizzle lizzle dizzle'
    >>> a2 = 'izzle quizzle izzle izzle izzle ovizzle izzle lizzle izzle'
    >>> #two options -> either replace words with 0 or 1 vowels with 'izzle' 
    >>> # or replace with 'izzle' starting at the first vowel
    >>> result in [a1, a2]
    True
    """

    #YOUR CODE HERE
    return ...


def apply_language_game(text, language_game):
    """Takes a text and a language_game function as inputs.
    Returns the language game function applied to every word of the text.
    >>> import hashlib
    >>> text = read_file("gettysburg.txt")
    >>> result = apply_language_game(text, str.upper) #Uppercases all words read from gettysburg.txt
    >>> result = result.split()
    >>> result[0:8]
    ['FOUR', 'SCORE', 'AND', 'SEVEN', 'YEARS', 'AGO', 'OUR', 'FATHERS']
    >>> pig = apply_language_game(text, pig_latin)
    >>> pig = pig.split()
    >>> pig[0:8]
    ['ourFay', 'orescay', 'anday', 'evensay', 'earsyay', 'agoay', 'ouray', 'athersfay']
    >>> #the code below checks if all contents of result are correct, do not worry about understanding the below code 
    >>> hash = '80dfef3eb95e94cd44163ecc7ae7aa96764948c0d884dc5d1e15bba4d2f6044e'
    >>> hashlib.sha256(str(pig).encode()).hexdigest() == hash #If this does not work, there may be a bug in your pig_latin implementation
    True
    """

    #YOUR CODE HERE
    return ...


def count_words(text):
    """Takes a text and returns a dictionary mapping each word to its count, for example:
    >>> result = count_words("Fruits and Vegetables and Vegetables on a Budget and Vegetables at a Store and Vegetables to Clean Fruit and Vegetables")
    >>> result == {'and': 5, 'on': 1, 'Vegetables': 5, 'Budget': 1, 'to': 1, 'Fruit': 1, 'a': 2, 'Clean': 1, 'Fruits': 1, 'Store': 1, 'at': 1}
    True
    >>> input = "apples and bananas and turkey and meat and bananas and apples and bananas and steak and a new professor."
    >>> expected = {'apples': 2, 'and': 8, 'bananas': 3, 'turkey': 1, 
    ... 'meat': 1, 'steak': 1, 'a': 1, 'new': 1, 'professor.': 1}
    >>> actual = count_words(input)
    >>> actual == expected
    True
    """

    #YOUR CODE HERE
    return ...


def top_n_words(counts, n):
    """Returns the top n words by count. In the case of a tie, it doesn't matter which words are chosen to break the tie.
    >>> top_n_words({'and': 5, 'on': 1, 'Vegetables': 5, 'Budget': 1, 
    ... 'to': 1, 'Fruit': 1, 'a': 2, 'Clean': 1, 'Fruits': 1, 'Store': 1, 'at': 1}, 2)
    ['and', 'Vegetables']
    >>> input = "apples and bananas and turkey and meat and bananas and apples and bananas and steak and a new professor."
    >>> counts = count_words(input)
    >>> top_n_words(counts, 3)
    ['and', 'bananas', 'apples']
    """

    #YOUR CODE HERE
    return ...


def print_top_n_words(counts, n):
    """Prints the top n words along with their counts.
    >>> print_top_n_words({'and': 5, 'on': 1, 'Vegetables': 5, 
    ... 'Budget': 1, 'to': 1, 'Fruit': 1, 'a': 2, 'Clean': 1, 'Fruits': 1, 'Store': 1, 'at': 1}, 2)
    and 5
    Vegetables 5
    >>> input = "apples and bananas and turkey and meat and apples and bananas and bananas and steak and a new professor."
    >>> counts = count_words(input)
    >>> print_top_n_words(counts, 3)
    and 8
    bananas 3
    apples 2
    """

    #YOUR CODE HERE
    pass


#OPTIONAL
def top_n_words_except(counts, n, boring):
    """
    Returns the top words except for anything that appears in boring,
    which is a list of boring words.
    >>> counts = {'and': 5, 'on': 1, 'Vegetables': 5, 'Budget': 1, 
    ... 'to': 1, 'Fruit': 1, 'a': 2, 'Clean': 1, 'Fruits': 1, 'Store': 1, 'at': 1}
    >>> top_n_words_except(counts, 2, ['and'])
    ['Vegetables', 'a']
    """

    #YOUR CODE HERE
    return ...



def average_word_length(counts):
    """Returns the average length of a text with given counts. For example:

    >>> average_word_length({'and': 5, 'on': 1, 'Vegetables': 5, 'Budget': 1, 'to': 1, 
    ... 'Fruit': 1, 'a': 2, 'Clean': 1, 'Fruits': 1, 'Store': 1, 'at': 1})
    5.0
    >>> dict = {'that': 13, 'the': 9, 'to': 8, 'we': 8, 'alpha': 7, 'and': 6, 'can': 5, 'have': 4}
    >>> x = average_word_length(dict)
    >>> x == 3.25
    True
    """
    """
    would return 5.0. This is because:
    Total letters: 3*5 + 2*1 + 10*5 + 6*1 + 2*1 + 5*1 + 1*2 + 5*1 + 6*1 + 5*1 + 2*1 = 100
    Total words: 5 + 1 + 5 + 1 + 1 + 1 + 2 + 1 + 1 + 1 + 1 = 20
    """

    #YOUR CODE HERE
    return ...


#OPTIONAL
def word_diversity(counts):
    """Returns the diversity of a text. 
    Test the diversity of the given input texts.
    >>> x = {'and': 5, 'on': 1, 'Vegetables': 5, 'Budget': 1, 'to': 1, 'Fruit': 1, 'a': 2, 'Clean': 1, 'Fruits': 1, 'Store': 1, 'at': 1}
    >>> word_diversity(x)
    0.55
    """

    #YOUR CODE HERE
    return ...

    
# OPTIONAL
def get_kgram(text, ptr, k):
    """Returns the kgram starting at position ptr in a text.
    >>> get_kgram("hello", 0, 3)
    'hel'
    >>> get_kgram("hello", 1, 3) 
    'ell'
    >>> get_kgram("hello", 1, 4) 
    'ello'
    """
    if len(text) < ptr + k:
        raise ValueError(f"{ptr} + {k} is longer than the length of {text}")
    #YOUR CODE HERE
    return ...


#OPTIONAL
def process_character(m, text, ptr, k):
    """Adds information about the given character to the model

    m is the model (a dictionary)
    text is the text
    text[ptr] is the character to be processed
    k is the order of our Markov chain
    >>> markovmodel = {}
    >>> process_character(markovmodel, "the ether", 0, 4)
    >>> process_character(markovmodel, "the ether", 1, 4)
    >>> process_character(markovmodel, "the ether", 2, 4)
    >>> expected = {'the ': {'e': 1}, 'he e': {'t': 1}, 'e et': {'h': 1}}
    >>> expected == markovmodel
    True
    """
    #YOUR CODE HERE
    return ...


#OPTIONAL
def build_markov_model(text, k):
    """ Returns the markov model for text.
    m is the model (a dictionary)
    text is the text
    k is the order of our Markov chain
    >>> expected = {'the': {' ': 1, 'r': 1}, 'he ': {'e': 1}, 'e e': {'t': 1}, ' et': {'h': 1}}
    >>> actual = build_markov_model("the ether", 3)
    >>> expected == actual
    True
    >>> expected = {'Beau': {'t': 1, 'y': 1}, 'eaut': {'y': 1}, 'auty': {' ': 1}, 'uty ': {'+': 1}, 'ty +': {' ': 1}}
    >>> actual = build_markov_model("Beauty + Joy", 4)
    >>> expected == actual
    True
    """

    #YOUR CODE HERE
    return ...

