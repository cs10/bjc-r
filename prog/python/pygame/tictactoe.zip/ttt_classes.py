import pygame as pg

class Game:
  #initiates gameboard and starts the game
  #Inputs: 
  # player1 is the first player, 
  # player2 is the second player
  #     both object types are Player Class objects
  # screen_length is the length of the screen
  # board is a 9 item list, each item represents a square on the tic tac toe board
  #       layout is as follows:
  #        0 | 1 | 2
  #       -----------
  #        3 | 4 | 5
  #       -----------
  #        6 | 7 | 8
  #     None spaces indicate empty spaces, 0 indicates player 1 piece, The default input is an 
  #     empty board or a list containing 9 None objects

    def __init__(self, player1, player2, screen_length, board = [None, None, None, None, None, None, None, None, None]):
        self.board = board

        # self.curr_turn tells the game who's turn it is. Player 1 goes first
        self.curr_turn = player1.piece
        self.p1 = player1
        self.p2 = player2
        self.length = screen_length
        # self.switch_players tells the game whether a game click has successfully placed an object,
        # and, as a result, should the current turn of the game be switched to the other player
        self.switch_players = False
        
        


    # updates the game information
    # only piece of game information for ttt is who's turn it is, update() changes
    # the self.curr_turn variable to the other player's turn whenever it is called
    def update(self):
        if self.switch_players:
            if self.curr_turn == self.p1.piece:
                self.curr_turn = self.p2.piece
                self.switch_players = False
            else:
                self.curr_turn = self.p1.piece
                self.switch_players = False
        


    # depending on where the mouse has clicked, and who's turn it is
    # this function will update the self.board variable to reflect a new
    # piece placement
    def game_click(self, x, y):
        

        if x <= self.length * (1/3):
            x_coor = 0
        elif x <= self.length * (2/3):
            x_coor = 1
        else:
            x_coor = 2

        if y <= self.length * (1/3):
            y_coor = 0
        elif y <= self.length * (2/3):
            y_coor = 1
        else:
            y_coor = 2

        index = ((y_coor * 3) + x_coor ) 

      
        if self.board[index] == None:

            self.board[index] = self.curr_turn
        
            self.switch_players = True

    # Screen
    def draw_board(self):
        #credit: https://dev.to/ramakm/a-simple-python-tic-tac-toe-game-using-pygame-1l8b


        rows = 3
        gameboard = pg.display.set_mode((self.length, self.length))
        pg.display.set_caption("TicTacToe")
    
        # Colors
        white = (255, 255, 255)
        black = (0, 0, 0)
    
        # loading images
        X_IMAGE = pg.transform.scale(pg.image.load("Images/x.png"), (100, 100))
        O_IMAGE = pg.transform.scale(pg.image.load("Images/o.png"), (100, 100))
        
        gap = self.length // rows
    
        #Drawing Board LInes
        for i in range(rows):
            x = i * gap
    
            pg.draw.line(gameboard, black, (x, 0), (x, self.length), 3)
            pg.draw.line(gameboard, black, (0, x), (self.length, x), 3)
        
        # Drawing all the pieces
        top_left_coordinates = [i * (self.length/rows) for i in range(rows)]
        for i in range(len(self.board)):
            if self.board[i] == 'x':
                x = top_left_coordinates[i%3]
                y = top_left_coordinates[i//3]
                gameboard.blit(X_IMAGE, (x, y))
            if self.board[i] == 'o':
                x = top_left_coordinates[i%3]
                y = top_left_coordinates[i//3]
                gameboard.blit(O_IMAGE, (x, y))
            
    # checks to see if the current player has a winning triple on the board 
    # winning triple algorithm is extremely simple. A player wins in ttt if
    # their pieces occupy 3 spaces in a row. a winning triple is a sries of indexes
    # where if a player had their pieces in all of the index of a winning triple,
    # they would win the game (i.e. columns, rows, and diagonals). If a player has
    # their pieces in any set of winning triple indexes, they will have won the game.
    def curr_player_win(self):
        winning_triples = [[0, 1, 2], [0, 4, 8], [2, 5, 8], [0, 3, 6], [1, 4, 7], [2, 4, 6], [3, 4, 5], [6, 7, 8]]
        piece = self.curr_turn
        for triple in winning_triples:
            if (self.board[triple[0]] == piece) and (self.board[triple[1]] == piece) and (self.board[triple[2]] == piece):
                return True
        return False

    # if there are no moves left on the board, return true, else return false
    def no_moves_left(self):
        if None in self.board:
            return False
        return True


# Plaer class:
# only input is the piece attribute, which is just a string to indicate piece of the 
# player (either "x" or "o")
class Player:
    def __init__(self, xo):
        self.piece = xo