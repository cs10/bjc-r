import pygame as pg
import random
import os
from ttt_classes import Game
from ttt_classes import Player

# Simple pygame program

# Import and initialize the pygame library
pg.init()

screen_length = 300

# Set up the drawing window
screen = pg.display.set_mode([screen_length, screen_length])

# player objects instantiating
player1 = Player("x")
player2 = Player("o")


# setting up a font for the game and setting up variables that describe colors via RGB values in a tuple
game_font = pg.font.SysFont("helvetica", 15)

red = (255,0,0)
green = (0,255,0)
black = (0,0,0)
white = (255,255,255)

# Instantiating the game
ttt_game = Game(player1, player2, screen_length)

# Run until the user asks to quit
running = True
while running:
    # fillling the screen with a background color
    screen.fill(white)

    
    for event in pg.event.get():
        # Did the user click the window close button?
        if event.type == pg.QUIT:
            running = False
        # is the player clicking on the screen right now?
        if event.type == pg.MOUSEBUTTONUP:
            x,y = pg.mouse.get_pos()
            ttt_game.game_click(x, y)

    # Checks if the current player has one after making their move
    if ttt_game.curr_player_win():
        running = False

        # displaying winning message
        font_color = green
        font_bg = white
        msg = ttt_game.curr_turn + " has won!"
        win_text = game_font.render(msg, True, font_color, font_bg)
        win_text_rect = win_text.get_rect()
        win_text_rect.center = screen_length/2, screen_length/2
        screen.blit(win_text,win_text_rect)
        pg.display.flip()
        pg.time.wait(1000)
    
    # Checks to see if there is a tie after the most recent move
    elif ttt_game.no_moves_left():
        running = False

        # Displays message for tie game
        font_color = red
        font_bg = white
        msg = "Tie Game!"
        win_text = game_font.render(msg, True, font_color, font_bg)
        win_text_rect = win_text.get_rect()
        win_text_rect.center = screen_length/2, screen_length/2
        screen.blit(win_text,win_text_rect)
        pg.display.flip()
        pg.time.wait(1000)
    
    #updates the ttt board
    ttt_game.update()

    # draws the ttt board
    ttt_game.draw_board()
    pg.display.flip()

# Done! Time to quit.
pg.quit()