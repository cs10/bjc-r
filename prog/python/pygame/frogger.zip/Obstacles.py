import pygame as pg
import random

class Obstacle(pg.sprite.Sprite):

    # lane_num: the number lane that the obstacle will be in
    # screen_width: width of the game screen 
    # screen_height: height of the game screen 
    # direction: either 1 or -1 for how the block should be moving
    # speed: how fast we want the object to move, higher number == faster speed
    # img_path: the location of the image of the car. Is a string
    # car_size: tuple with the dimensions of the car object: (Width, Height)

    def __init__(self, lane_num, screen_width, screen_height, direction, speed, img_path, car_size):
        pg.sprite.Sprite.__init__(self)
        self.lane_num = lane_num
        
        self.width = car_size[0]
        self.height = car_size[1]
       
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        # self.finished will mark if an obstacle has driven off the screen or not. If it has, self.finished == True,
        # else, self.finished == False
        self.finished = False
        self.direction = direction

        if self.direction == 1:
            self.image = pg.transform.scale(pg.image.load(img_path), car_size)
        else:
            self.image = pg.transform.flip(pg.transform.scale(pg.image.load(img_path), car_size), True, False)

        self.rect = self.image.get_rect()
        self.move_x = 0

        self.speed = speed

       # starts an obstacle at the edge of the screen, used when obstacles are replaced
    def start(self):
        if self.direction == 1:
            self.rect.x = (0 - self.width - random.randint(25, 150))
        else:
            self.rect.x = (self.screen_width + self.width + random.randint(25, 150))

        
        self.rect.y = self.screen_height - ((self.lane_num+1) * self.height)


    # sets the position of an obstacle directly
    def set_pos(self, x, y):
        self.rect.x = x
        self.rect.y = y

    # used to move the obstacle, if the end side of the obstacle reaches the end of
    # the lane, the obstacle's "finished" variable is set to True, and the game script
    # replaces it with a new obstacle that starts at the starting position. This move
    # function will depend on the lane's velocity and direction variables
    def move(self):
        self.move_x += self.speed * self.direction
        if (self.rect.x > self.screen_width and self.direction == 1) or (self.rect.x < 0 and self.direction == -1):
            self.finished = True


    # updates the position of an obstacle
    def update(self):
        self.rect.x += self.move_x
        self.move_x = 0

    
