import pygame as pg
import pygame.freetype as freetype
import random
import os
from Game import Game
from Frog import Frog
from Obstacles import Obstacle



# Simple pygame program
screen_width = 700
screen_height = 600
num_lanes = 6
fps = 40

# setting variables for colors
black = (0,0,0)
white = (255,255,255)

# Import and initialize the pygame library
pg.init()

# Set up the drawing window
screen = pg.display.set_mode([screen_width,screen_height])

# Instantiating clock object
clock = pg.time.Clock()


# Instantiating Frog
frog = Frog(screen_width/2, screen_height, screen_height/(num_lanes),num_lanes, screen_width, screen_height, 0)


# Creating sprite groups for the frog and obstacles (sprites and groups are explained in the Pygame Guide)
frog_group = pg.sprite.Group()
obs_group = pg.sprite.Group()

frog_group.add(frog)

# Instantiating Game
f_game = Game(num_lanes,3, screen_height, screen_width, obs_group)

# generating obstacles for the game 
f_game.generate_obstacles()

running = True
while running:

    # If the player loses/runs out of lives
    if f_game.num_lives <= 0:
        running = False

        #displaying losing message
        font_color = black
        font_bg = white
        font = pg.font.Font('freesansbold.ttf', 32)
        lose_text = font.render("You've lost! :( ", True, font_color, font_bg)
        lose_text_rect = lose_text.get_rect()
        lose_text_rect.center = screen_width/2, screen_height/2
        screen.blit(lose_text,lose_text_rect)
        
        pg.display.flip()
        pg.time.wait(1000)

    # if the player makes it across all the lanes
    elif frog.frog_win():
        running = False

        #displaying winning message
        font_color = black
        font_bg = white
        font = pg.font.Font('freesansbold.ttf', 32)
        win_text = font.render("You've won! :) ", True, font_color, font_bg)
        win_text_rect = win_text.get_rect()
        win_text_rect.center = screen_width/2, screen_height/2
        screen.blit(win_text,win_text_rect)
        
        pg.display.flip()
        pg.time.wait(1000)


    # Code for handling key presses and hitting the exit button
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_UP:
                frog.move_frog("UP")
            elif event.key == pg.K_DOWN:
                frog.move_frog("DOWN")
            elif event.key == pg.K_LEFT:
                frog.move_frog("LEFT")
            elif event.key == pg.K_RIGHT:
                frog.move_frog("RIGHT")



    # Seeing if frog and obstacles have collided
    if pg.sprite.spritecollideany(frog, obs_group):
        frog.collision_reset()
        f_game.num_lives -= 1

    # checking for finished cars and replacing them
    for car in obs_group:
        if car.finished:
            f_game.replace_obs(car)


    #updating Object positions
    for car in obs_group:
        car.move()

    # update functions
    frog.update()
    obs_group.update()
    

    #Fill Screen and then Draw things
    screen.fill((0,0,0))
    f_game.draw_lives(70, 30, screen)
    
    obs_group.draw(screen)
    frog_group.draw(screen)


    #pg display things
    pg.display.flip()
    clock.tick(fps)

# Done! Time to quit.
pg.quit()