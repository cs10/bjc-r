import pygame as pg

class Frog(pg.sprite.Sprite):
    # start_x: starting x position of frog
    # start_y: starting y position of frog
    # block_size: size of a step when the frog moves, also size of frog is 
    #   block_size x bloxk_size
    # num_lanes: how many lanes are there in the game?
    # screen_width: width of the screen
    # screen_height: height of the screen
    # lane: what lane the frog starts in (default to 0)


    def __init__(self, start_x, start_y, block_size, num_lanes, screen_width, screen_height,lane = 0):
        pg.sprite.Sprite.__init__(self)
        self.x = start_x
        self.y = start_y

        self.width = block_size
        self.height = block_size
        self.lane = lane

        # move variables used in the move_frog function and update function
        self.move_x = 0
        self.move_y = 0

        self.num_lanes = num_lanes
        self.screen_width = screen_width
        self.screen_height = screen_height
        
        # image and rect attributes of the sprites
        self.image = pg.transform.scale(pg.image.load("img/frog.png"), (int(block_size), int(block_size)))
        self.rect = self.image.get_rect()

        # starting position of the frog (center of the bottom row)
        self.rect.x, self.rect.y = (self.screen_width/2) - (block_size/2), (self.screen_height) - (block_size)

    
    # Directions include "UP", "DOWN", "LEFT", and "RIGHT". Frog should move one lane's 
    # height at a time, or one frog block size with every key press. Frog's lane should
    # also change depending on the direction moved
    def move_frog(self, direction):
        if (self.lane == self.num_lanes and direction == "UP") or (direction == "LEFT" and self.rect.x - self.width < 0) or (direction == "RIGHT" and self.rect.x + self.width >= self.screen_width):
            return
        elif direction == "UP":
            self.lane += 1
            self.move_y -= self.width
        elif direction == "DOWN":
            self.lane -= 1
            self.move_y += self.width
        elif direction == "LEFT":
            self.move_x -= self.width
        elif direction == "RIGHT":
            self.move_x += self.width
        
        

    # Resets and draws the frog at the starting position

    def collision_reset(self):
        self.rect.x, self.rect.y = (self.screen_width/2) - (self.width/2), (self.screen_height) - (self.height)
        self.lane = 0
    # Frog has made it into the last lane
    def frog_win(self):
        
        return self.lane == self.num_lanes - 1

    def update(self):
        self.rect.x += self.move_x
        self.rect.y += self.move_y
        self.move_x = 0
        self.move_y = 0

