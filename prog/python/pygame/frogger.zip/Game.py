import pygame as pg

from Obstacles import Obstacle

import random

class Game:

    # num_lanes: How many total lanes is wanted in this game, minimum is two for start and end lanes. includes start, end and traffic lanes
    # num_lives: Game over when this number reaches 0

    def __init__(self, num_lanes, num_lives, screen_height, screen_width,obstacle_group):
        self.num_lives = num_lives
        self.obstacle_group = obstacle_group
        self.num_lanes  = num_lanes
        self.screen_height = screen_height
        self.screen_width = screen_width


    # takes the obstacle where obs.finished == True out of the the lanes dictionary 
    # and replaces and it with a new one
    def replace_obs(self, obs):
        obs_lane = obs.lane_num

        # We dont want the new obstacle to always be the same. the next couple lines
        # of code ensures that the a long blue car is generated about 1/3 of the time
        if random.randint(1, 3) == 1:
            new_obs = Obstacle(obs_lane, obs.screen_width, obs.screen_height, obs.direction, obs_lane *2, "img/blue_car.png", (150,100))
        else:
            new_obs = Obstacle(obs_lane, obs.screen_width, obs.screen_height, obs.direction, obs_lane *2, "img/yellow_car.png", (100,100))

        # Taking the original obstacle out of the obstacle group
        obs.kill()

        #adding new obstacel to obstacle group
        self.obstacle_group.add(new_obs)
        new_obs.start()
    

    #displays the number of lives remaining at coordinate (num_lives_x, num_lives_y)
    def draw_lives(self, num_lives_x, num_lives_y, screen):
        font_color = (0,0,0)
        font_bg = (255, 255, 255)
        num_life_font = pg.font.Font('freesansbold.ttf', 32)
        num_life_text = num_life_font.render("Lives: "+str(self.num_lives), True, font_color, font_bg)
        num_life_rect = num_life_text.get_rect()
        num_life_rect.center = num_lives_x, num_lives_y
        screen.blit(num_life_text,num_life_rect)


    # Generate obstacles generates all the obstacles when the game first starts. It is only called once 
    # as new obstacles will be generated using the replace_obs function
    def generate_obstacles(self):

        # generating obstacles for each lane (except for the first lane and last lane where there are no obstacles)
        for lane_num in range(1,self.num_lanes-1):

            # randomly determining the direction of the lane
            sign = random.choice([1,-1])
            x_val = 0

            # y value for each obstacle in a lane is determined by the screen height and number of lanes
            y_val = self.screen_height - ((lane_num+1) * (self.screen_height/self.num_lanes))
           
            # this code generates all the obstacles for a particular lane, will run until the entire lane is filled up with obstacles
            while x_val < self.screen_width:

                # like the replace function, next few lines randomizes which car is generated as an obstacle
                if random.randint(1, 3) == 1:
                    new_obs = Obstacle(lane_num, self.screen_width, self.screen_height, sign, lane_num * 2, "img/blue_car.png", (150,100))
                else:
                    new_obs = Obstacle(lane_num, self.screen_width, self.screen_height, sign, lane_num * 2, "img/yellow_car.png", (100,100))
                    new_obs.set_pos(x_val, y_val)
                    self.obstacle_group.add(new_obs)

                    # randomizes the gap between each obstacle
                    x_val += new_obs.width + random.randint(130, 250)
                    

       



